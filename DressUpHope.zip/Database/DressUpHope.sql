CREATE DATABASE  IF NOT EXISTS `gbdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `gbdb`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: gbdb
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adress`
--

DROP TABLE IF EXISTS `adress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adress` (
  `idadress` int NOT NULL AUTO_INCREMENT,
  `city` varchar(45) NOT NULL,
  `district` varchar(100) NOT NULL,
  PRIMARY KEY (`idadress`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adress`
--

LOCK TABLES `adress` WRITE;
/*!40000 ALTER TABLE `adress` DISABLE KEYS */;
INSERT INTO `adress` VALUES (1,'Ankara','Meydan'),(2,'?stanbul','Meydan'),(3,'Trabzon','Meydan'),(4,'?zmir','Meydan'),(5,'Bursa','Meydan'),(6,'Antalya','Meydan'),(7,'Kayseri','Meydan'),(8,'Konya','Meydan'),(9,'Samsun','Meydan'),(10,'Mu?la','Meydan'),(11,'Pune','Pune'),(12,'Chindhwad','Pune'),(13,'Alandi','Pune'),(14,'Hinjawadi','Pune'),(15,'Akurdi','Pune'),(16,'Chinchwad','Pune');
/*!40000 ALTER TABLE `adress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `arrived_cloths`
--

DROP TABLE IF EXISTS `arrived_cloths`;
/*!50001 DROP VIEW IF EXISTS `arrived_cloths`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `arrived_cloths` AS SELECT 
 1 AS `username`,
 1 AS `idcloth`,
 1 AS `clothType`,
 1 AS `clothSize`,
 1 AS `hangarName`,
 1 AS `name`,
 1 AS `surname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `avaliable_cloths_in_given_hangar`
--

DROP TABLE IF EXISTS `avaliable_cloths_in_given_hangar`;
/*!50001 DROP VIEW IF EXISTS `avaliable_cloths_in_given_hangar`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `avaliable_cloths_in_given_hangar` AS SELECT 
 1 AS `idcloth`,
 1 AS `clothType`,
 1 AS `clothSize`,
 1 AS `hangarName`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `cloth`
--

DROP TABLE IF EXISTS `cloth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cloth` (
  `idcloth` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `clothSize` varchar(45) NOT NULL,
  `clothType` varchar(45) NOT NULL,
  `hangarId` int DEFAULT NULL,
  PRIMARY KEY (`idcloth`),
  KEY `cloth_FK2_idx` (`hangarId`),
  KEY `cloth_FK1_idx` (`userId`),
  CONSTRAINT `cloth_FK1` FOREIGN KEY (`userId`) REFERENCES `user` (`iduser`),
  CONSTRAINT `cloth_FK2` FOREIGN KEY (`hangarId`) REFERENCES `hangar` (`idhangar`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloth`
--

LOCK TABLES `cloth` WRITE;
/*!40000 ALTER TABLE `cloth` DISABLE KEYS */;
INSERT INTO `cloth` VALUES (1,1,'M','T-Shirt',1),(2,2,'XXL','T-Shirt',2),(3,3,'L','Pants',1),(4,3,'S','Skirt',1),(5,4,'M','T-Shirt',1),(6,4,'L','Skirt',2),(7,1,'XL','T-Shirt',1),(8,2,'M','Pants',3),(9,5,'XL','Shirt',2),(10,5,'XL','shirt',12),(11,5,'L','Shirt',12),(12,6,'XL','Shirt',13),(13,7,'XL','Shirt',14),(14,8,'XXL','Shirt',14);
/*!40000 ALTER TABLE `cloth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `cloth_didnt_arrive_hangar`
--

DROP TABLE IF EXISTS `cloth_didnt_arrive_hangar`;
/*!50001 DROP VIEW IF EXISTS `cloth_didnt_arrive_hangar`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `cloth_didnt_arrive_hangar` AS SELECT 
 1 AS `idcloth`,
 1 AS `clothType`,
 1 AS `clothSize`,
 1 AS `hangarName`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `clothgiver`
--

DROP TABLE IF EXISTS `clothgiver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clothgiver` (
  `idclothgiver` int NOT NULL,
  `clothGivenCount` int NOT NULL,
  PRIMARY KEY (`idclothgiver`),
  KEY `clothgiver_FK1_idx` (`idclothgiver`),
  CONSTRAINT `clothgiver_FK1` FOREIGN KEY (`idclothgiver`) REFERENCES `user` (`iduser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clothgiver`
--

LOCK TABLES `clothgiver` WRITE;
/*!40000 ALTER TABLE `clothgiver` DISABLE KEYS */;
INSERT INTO `clothgiver` VALUES (1,0),(2,0),(3,0),(4,0),(5,5),(6,3),(7,3),(8,3);
/*!40000 ALTER TABLE `clothgiver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `cloths_waiting_for_transfer`
--

DROP TABLE IF EXISTS `cloths_waiting_for_transfer`;
/*!50001 DROP VIEW IF EXISTS `cloths_waiting_for_transfer`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `cloths_waiting_for_transfer` AS SELECT 
 1 AS `idcloth`,
 1 AS `clothType`,
 1 AS `clothSize`,
 1 AS `hangarName`,
 1 AS `username`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `clothtaker`
--

DROP TABLE IF EXISTS `clothtaker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clothtaker` (
  `idclothtaker` int NOT NULL,
  `lowerSize` varchar(45) NOT NULL,
  `upperSize` varchar(45) NOT NULL,
  `clothTakenCount` int NOT NULL,
  PRIMARY KEY (`idclothtaker`),
  CONSTRAINT `clothtaker_FK1` FOREIGN KEY (`idclothtaker`) REFERENCES `person` (`idperson`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clothtaker`
--

LOCK TABLES `clothtaker` WRITE;
/*!40000 ALTER TABLE `clothtaker` DISABLE KEYS */;
INSERT INTO `clothtaker` VALUES (51,'L','L',0);
/*!40000 ALTER TABLE `clothtaker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `clothtaking_person`
--

DROP TABLE IF EXISTS `clothtaking_person`;
/*!50001 DROP VIEW IF EXISTS `clothtaking_person`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `clothtaking_person` AS SELECT 
 1 AS `idperson`,
 1 AS `name`,
 1 AS `surname`,
 1 AS `lowerSize`,
 1 AS `upperSize`,
 1 AS `city`,
 1 AS `district`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `giveaway`
--

DROP TABLE IF EXISTS `giveaway`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `giveaway` (
  `idgiveaway` int NOT NULL AUTO_INCREMENT,
  `clothId` int NOT NULL,
  `transporterId` int DEFAULT NULL,
  `takenDate` date NOT NULL,
  `arrivalDate` date DEFAULT NULL,
  `clothgiverId` int NOT NULL,
  `hangarId` int NOT NULL,
  PRIMARY KEY (`idgiveaway`),
  KEY `giveaway_FK1_idx` (`clothId`),
  KEY `giveaway_FK3_idx` (`clothgiverId`),
  KEY `giveaway_FK4_idx` (`hangarId`),
  KEY `giveaway_FK2_idx` (`transporterId`),
  CONSTRAINT `giveaway_FK1` FOREIGN KEY (`clothId`) REFERENCES `cloth` (`idcloth`),
  CONSTRAINT `giveaway_FK2` FOREIGN KEY (`transporterId`) REFERENCES `transporter` (`idtransporter`),
  CONSTRAINT `giveaway_FK3` FOREIGN KEY (`clothgiverId`) REFERENCES `clothgiver` (`idclothgiver`),
  CONSTRAINT `giveaway_FK4` FOREIGN KEY (`hangarId`) REFERENCES `hangar` (`idhangar`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `giveaway`
--

LOCK TABLES `giveaway` WRITE;
/*!40000 ALTER TABLE `giveaway` DISABLE KEYS */;
INSERT INTO `giveaway` VALUES (1,1,1,'2021-05-25','2020-06-01',3,1),(2,2,1,'2021-05-25',NULL,3,1),(3,4,1,'2021-05-25','2020-06-01',3,1),(4,9,NULL,'2023-12-20',NULL,5,2),(5,10,NULL,'2023-12-20','2023-12-20',5,12),(6,11,NULL,'2023-12-20','2023-12-20',5,12),(7,12,NULL,'2023-12-21','2023-12-21',6,13),(8,13,NULL,'2023-12-22','2023-12-22',7,14),(9,14,NULL,'2023-12-22','2023-12-22',8,14);
/*!40000 ALTER TABLE `giveaway` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hangar`
--

DROP TABLE IF EXISTS `hangar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hangar` (
  `idhangar` int NOT NULL AUTO_INCREMENT,
  `hangarPassword` varchar(45) NOT NULL,
  `addressId` int NOT NULL,
  `hangarName` varchar(45) NOT NULL,
  PRIMARY KEY (`idhangar`),
  KEY `hangar_FK1_idx` (`addressId`),
  CONSTRAINT `hangar_FK1` FOREIGN KEY (`addressId`) REFERENCES `adress` (`idadress`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hangar`
--

LOCK TABLES `hangar` WRITE;
/*!40000 ALTER TABLE `hangar` DISABLE KEYS */;
INSERT INTO `hangar` VALUES (1,'23487',1,'Alandi ngo'),(2,'23485',2,'PCMC ngo'),(3,'34523',3,'Nigadi ngo'),(4,'78643',4,'Chinchwad ngo'),(5,'34532',5,'Pimpri ngo'),(6,'23487',6,'Akurdi ngo'),(7,'87483',7,'Hinjawadi ngo'),(8,'53435',8,'Chikhali ngo'),(9,'98564',9,'Dehugaon ngo'),(10,'98746',10,'Chakan ngo'),(12,'20003',11,'Pune ngo'),(13,'20003',12,'Bopkhel ngo'),(14,'20003',13,'ASM ngo');
/*!40000 ALTER TABLE `hangar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `on_the_way_cloths`
--

DROP TABLE IF EXISTS `on_the_way_cloths`;
/*!50001 DROP VIEW IF EXISTS `on_the_way_cloths`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `on_the_way_cloths` AS SELECT 
 1 AS `username`,
 1 AS `clothId`,
 1 AS `clothType`,
 1 AS `clothSize`,
 1 AS `hangarName`,
 1 AS `name`,
 1 AS `surname`,
 1 AS `transporterId`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `person` (
  `idperson` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `surname` varchar(45) NOT NULL,
  `sex` varchar(45) NOT NULL,
  `adressId` int NOT NULL,
  PRIMARY KEY (`idperson`),
  KEY `person_FK1_idx` (`adressId`),
  CONSTRAINT `person_FK1` FOREIGN KEY (`adressId`) REFERENCES `adress` (`idadress`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,'Mustafa','Demiröz','male',3),(2,'Sukufe','Arsoy','female',2),(3,'Nur','Güçlü','female',1),(4,'Yazganalp','Sakarya','male',1),(5,'Tarık','Güçlü','male',4),(6,'Yücelen','Mansız','male',2),(7,'Emine','Safak','female',2),(8,'Deviner','Bilge','male',9),(9,'Elif','Mansız','female',8),(10,'Sanur','Yüksel','female',10),(11,'Dilder','Karadeniz','female',5),(12,'Alaaddin','Korutürk','male',2),(13,'Duruk','Erdo?an','male',4),(14,'Nursan','Yıldırım','female',8),(15,'Aydinç','Demir','male',1),(16,'Abdurrahman','Sener','male',2),(17,'Bilge','Eraslan','female',1),(18,'Ali','Zengin','male',2),(19,'Ahmet','Erdo?an','male',8),(20,'Mehmet','Durdu','male',9),(21,'Ayse','Akgündüz','female',7),(22,'Nazım','Bilir','male',6),(23,'Mü?ber','Sezer','male',1),(24,'Rıza','Akça','male',2),(25,'Nadir','Türk','male',10),(26,'Yaren','?ensoy','female',1),(27,'Yudum','Aslan','female',4),(28,'Beyza','Güçlü','female',1),(29,'Akif','Ergül','male',9),(30,'Melik','Soylu','male',1),(31,'Berat','Aylak','male',2),(32,'Ahmet','Aydın','male',1),(33,'Melek','Erdal','female',2),(34,'Nursena','Tütüncü','female',2),(35,'Ali','Engin','male',2),(36,'Elif','Tasdemir','female',2),(37,'Öktem','Güvenç','male',1),(38,'Nisa','Ate?','female',1),(39,'Kadir','Yesilyurt','male',1),(40,'Ugur','Gökdemir','male',2),(41,'Mustafa','Öztaskın','male',2),(42,'Ismail','Sulak','male',3),(43,'Berat','Demircan','male',8),(44,'Anıl','Gürdemir','male',7),(45,'Batuhan','Demirtürk','male',6),(46,'Emine','Akcan','female',4),(47,'Merve','Yaldız','female',3),(48,'Hüma','Bayazıt','female',7),(49,'Zeynep','Altunsoy','female',6),(50,'Eren','Ercan','male',5),(51,'Chaitali','BISEN','female',11),(52,'Mohammad','SHAIKH','male',12),(53,'Jaya','BARI','female',13),(54,'Chaitali','BISEN','female',14),(55,'Mohammad','SHAIKH','male',15),(56,'Asm','IBRM','male',16),(57,'Gaurav','BARI','male',16),(58,'Chaitali','BISEN','female',14),(59,'Ganesh','BARI','male',13);
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `takes`
--

DROP TABLE IF EXISTS `takes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `takes` (
  `idtakes` int NOT NULL AUTO_INCREMENT,
  `arrivalDate` date DEFAULT NULL,
  `transporterId` int NOT NULL,
  `clothId` int NOT NULL,
  `takenDate` date NOT NULL,
  `clothTakerId` int DEFAULT NULL,
  `hangarId` int NOT NULL,
  PRIMARY KEY (`idtakes`),
  KEY `takes_FK4_idx` (`clothTakerId`),
  KEY `takes_FK1_idx` (`clothId`),
  KEY `takes_FK3_idx` (`hangarId`),
  KEY `takes_FK2_idx` (`transporterId`),
  CONSTRAINT `takes_FK1` FOREIGN KEY (`clothId`) REFERENCES `cloth` (`idcloth`),
  CONSTRAINT `takes_FK2` FOREIGN KEY (`transporterId`) REFERENCES `transporter` (`idtransporter`),
  CONSTRAINT `takes_FK3` FOREIGN KEY (`hangarId`) REFERENCES `hangar` (`idhangar`),
  CONSTRAINT `takes_FK4` FOREIGN KEY (`clothTakerId`) REFERENCES `clothtaker` (`idclothtaker`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `takes`
--

LOCK TABLES `takes` WRITE;
/*!40000 ALTER TABLE `takes` DISABLE KEYS */;
INSERT INTO `takes` VALUES (6,'2023-12-21',8,12,'2023-12-21',51,13),(7,'2023-12-22',9,13,'2023-12-22',51,14),(8,'2023-12-22',9,14,'2023-12-22',51,14);
/*!40000 ALTER TABLE `takes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transporter`
--

DROP TABLE IF EXISTS `transporter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transporter` (
  `idtransporter` int NOT NULL AUTO_INCREMENT,
  `personId` int NOT NULL,
  `hangarId` int NOT NULL,
  PRIMARY KEY (`idtransporter`),
  KEY `transporter_FK2_idx` (`hangarId`),
  KEY `transporter_FK1_idx` (`personId`),
  CONSTRAINT `transporter_FK1` FOREIGN KEY (`personId`) REFERENCES `person` (`idperson`),
  CONSTRAINT `transporter_FK2` FOREIGN KEY (`hangarId`) REFERENCES `hangar` (`idhangar`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transporter`
--

LOCK TABLES `transporter` WRITE;
/*!40000 ALTER TABLE `transporter` DISABLE KEYS */;
INSERT INTO `transporter` VALUES (1,15,1),(2,16,2),(3,17,3),(4,18,4),(5,19,5),(6,20,6),(7,52,12),(8,52,13),(9,57,14);
/*!40000 ALTER TABLE `transporter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `transporter_information`
--

DROP TABLE IF EXISTS `transporter_information`;
/*!50001 DROP VIEW IF EXISTS `transporter_information`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `transporter_information` AS SELECT 
 1 AS `idtransporter`,
 1 AS `name`,
 1 AS `surname`,
 1 AS `hangarName`,
 1 AS `hangarId`,
 1 AS `personId`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `iduser` int NOT NULL AUTO_INCREMENT,
  `personId` int NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`iduser`),
  KEY `user_FK1_idx` (`personId`),
  CONSTRAINT `user_FK1` FOREIGN KEY (`personId`) REFERENCES `person` (`idperson`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,1,'sandarsa','1234'),(2,2,'yolgezer','12345'),(3,3,'apollo','1234'),(4,4,'america','1234567'),(5,5,'nobody','pass'),(6,53,'jaya997','1234'),(7,56,'asm123','asm123'),(8,59,'ganeshbari997','Ganesh@11');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `arrived_cloths`
--

/*!50001 DROP VIEW IF EXISTS `arrived_cloths`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `arrived_cloths` AS select `u`.`username` AS `username`,`c`.`idcloth` AS `idcloth`,`c`.`clothType` AS `clothType`,`c`.`clothSize` AS `clothSize`,`h`.`hangarName` AS `hangarName`,`p`.`name` AS `name`,`p`.`surname` AS `surname` from ((((`person` `p` join `takes` `t` on((`p`.`idperson` = `t`.`clothTakerId`))) join `cloth` `c` on((`t`.`clothId` = `c`.`idcloth`))) join `user` `u` on((`c`.`userId` = `u`.`iduser`))) join `hangar` `h` on((`t`.`hangarId` = `h`.`idhangar`))) where (`t`.`arrivalDate` is not null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `avaliable_cloths_in_given_hangar`
--

/*!50001 DROP VIEW IF EXISTS `avaliable_cloths_in_given_hangar`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `avaliable_cloths_in_given_hangar` AS select `c`.`idcloth` AS `idcloth`,`c`.`clothType` AS `clothType`,`c`.`clothSize` AS `clothSize`,`h`.`hangarName` AS `hangarName` from ((`giveaway` `g` join `cloth` `c` on((`g`.`clothId` = `c`.`idcloth`))) join `hangar` `h` on((`c`.`hangarId` = `h`.`idhangar`))) where ((`g`.`arrivalDate` is not null) and `c`.`idcloth` in (select `takes`.`clothId` from `takes`) is false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cloth_didnt_arrive_hangar`
--

/*!50001 DROP VIEW IF EXISTS `cloth_didnt_arrive_hangar`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cloth_didnt_arrive_hangar` AS select `c`.`idcloth` AS `idcloth`,`c`.`clothType` AS `clothType`,`c`.`clothSize` AS `clothSize`,`h`.`hangarName` AS `hangarName` from ((`giveaway` `g` join `cloth` `c` on((`g`.`clothId` = `c`.`idcloth`))) join `hangar` `h` on((`c`.`hangarId` = `h`.`idhangar`))) where ((`g`.`arrivalDate` is null) and `c`.`idcloth` in (select `takes`.`clothId` from `takes`) is false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cloths_waiting_for_transfer`
--

/*!50001 DROP VIEW IF EXISTS `cloths_waiting_for_transfer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cloths_waiting_for_transfer` AS select `c`.`idcloth` AS `idcloth`,`c`.`clothType` AS `clothType`,`c`.`clothSize` AS `clothSize`,`h`.`hangarName` AS `hangarName`,`u`.`username` AS `username` from ((`cloth` `c` join `hangar` `h` on((`c`.`hangarId` = `h`.`idhangar`))) join `user` `u` on((`c`.`userId` = `u`.`iduser`))) where `c`.`idcloth` in (select `takes`.`clothId` from `takes`) is false */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `clothtaking_person`
--

/*!50001 DROP VIEW IF EXISTS `clothtaking_person`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `clothtaking_person` AS select `person`.`idperson` AS `idperson`,`person`.`name` AS `name`,`person`.`surname` AS `surname`,`clothtaker`.`lowerSize` AS `lowerSize`,`clothtaker`.`upperSize` AS `upperSize`,`adress`.`city` AS `city`,`adress`.`district` AS `district` from ((`person` join `clothtaker`) join `adress` on(((`person`.`idperson` = `clothtaker`.`idclothtaker`) and (`person`.`adressId` = `adress`.`idadress`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `on_the_way_cloths`
--

/*!50001 DROP VIEW IF EXISTS `on_the_way_cloths`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `on_the_way_cloths` AS select `user`.`username` AS `username`,`takes`.`clothId` AS `clothId`,`cloth`.`clothType` AS `clothType`,`cloth`.`clothSize` AS `clothSize`,`hangar`.`hangarName` AS `hangarName`,`person`.`name` AS `name`,`person`.`surname` AS `surname`,`takes`.`transporterId` AS `transporterId` from ((((`person` join `takes`) join `cloth`) join `user`) join `hangar` on(((`hangar`.`idhangar` = `takes`.`hangarId`) and (`cloth`.`userId` = `user`.`iduser`) and (`takes`.`clothTakerId` = `person`.`idperson`) and (`cloth`.`idcloth` = `takes`.`clothId`)))) where (`takes`.`arrivalDate` is null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `transporter_information`
--

/*!50001 DROP VIEW IF EXISTS `transporter_information`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `transporter_information` AS select `transporter`.`idtransporter` AS `idtransporter`,`person`.`name` AS `name`,`person`.`surname` AS `surname`,`hangar`.`hangarName` AS `hangarName`,`transporter`.`hangarId` AS `hangarId`,`transporter`.`personId` AS `personId` from ((`transporter` join `hangar`) join `person` on(((`hangar`.`idhangar` = `transporter`.`hangarId`) and (`person`.`idperson` = `transporter`.`personId`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-27 20:49:28
