
package cloth;


public class Database {
     public static final String userName = "root";
     public static final String password = "Gaurav@21"; // it is needod to handle in your machine 
     public static final String db_name = "gbdb"; //it is needod to handle in your machine 
     public  static final String host = "localhost";
     public static final int port = 3306;
    
}
