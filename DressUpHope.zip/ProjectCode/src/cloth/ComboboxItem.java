
package cloth;


public class ComboboxItem {
     private String id ;
    private String name;
    public String GetId(){return id;}
    public void SetId(String Id){ id=Id;}
    public String GetName(){return name;}
    public void SetName(String Adi){ name=Adi;}
    
    ComboboxItem(String Id,String Adi){
        this.id = Id;
        this.name=Adi;
    }
    public ComboboxItem(){
    super();
    }
    public String toString(){
        return this.name;
    }
}
