
package cloth;


public class ClothTable {
    private int ClothId;
    private String ClothType;
    private String ClothSize;

    public ClothTable(int ClothId, String ClothType, String ClothSize) {
        this.ClothId = ClothId;
        this.ClothType = ClothType;
        this.ClothSize = ClothSize;
    }

    public int getClothId() {
        return ClothId;
    }

    public void setClothId(int ClothId) {
        this.ClothId = ClothId;
    }

    public String getClothType() {
        return ClothType;
    }

    public void setClothType(String ClothType) {
        this.ClothType = ClothType;
    }

    public String getClothSize() {
        return ClothSize;
    }

    public void setClothSize(String ClothSize) {
        this.ClothSize = ClothSize;
    }
}
